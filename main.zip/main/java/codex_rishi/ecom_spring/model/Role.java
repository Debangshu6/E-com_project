package codex_rishi.ecom_spring.model;

public enum Role {
    USER,
    ADMIN
}
