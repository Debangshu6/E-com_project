package codex_rishi.ecom_spring.service;

import codex_rishi.ecom_spring.model.CartItem;
import codex_rishi.ecom_spring.model.Product;
import codex_rishi.ecom_spring.model.User;
import codex_rishi.ecom_spring.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartItemRepository cartItemRepository;

    // ✅ Add product to cart
    public CartItem addToCart(User user, Product product, int quantity) {// addToCart method takes User, Product, and quantity as parameters
        CartItem existingItem = cartItemRepository.findByProduct_IdAndUser_Id((long) product.getId(), user.getId());// find existing CartItem for the user and product

        if (existingItem != null) {
            // Product already in cart — update quantity
            existingItem.setQuantity(existingItem.getQuantity() + quantity);
            return cartItemRepository.save(existingItem);
        } else {
            // New product — create new CartItem
            CartItem newItem = new CartItem();
            newItem.setUser(user);
            newItem.setProduct(product);
            newItem.setQuantity(quantity);
            return cartItemRepository.save(newItem);
        }
    }



    // ✅ Get all cart items for the logged-in user
    public List<CartItem> getCartItemsByUser(User user) {// getCartItemsByUser method takes User as a parameter
        return cartItemRepository.findAllByUser_Id(user.getId());
    }

    // ✅ Remove item from user's cart
    @Transactional
    public void removeFromCart(Long userId, Long productId) {
        cartItemRepository.deleteByProduct_IdAndUser_Id(productId, userId);
    }
}
