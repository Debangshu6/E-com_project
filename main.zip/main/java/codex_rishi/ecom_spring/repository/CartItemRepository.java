package codex_rishi.ecom_spring.repository;

import codex_rishi.ecom_spring.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    CartItem findByProduct_IdAndUser_Id(Long productId, Long userId);  //select * from CartItem where product_id = ? and user_id = ?
    void deleteByProduct_IdAndUser_Id(Long productId, Long userId);// delete from CartItem where product_id = ? and user_id = ?
    List<CartItem> findAllByUser_Id(Long userId);// select * from CartItem where user_id = ?

}


