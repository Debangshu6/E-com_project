package codex_rishi.ecom_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EComSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(EComSpringApplication.class, args);
    }

}
